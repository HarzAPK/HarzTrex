package com.micha.trexroar

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class TrexView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State { ANGRY, GRIN }
    var state: State = State.ANGRY
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D4D4D4")
        style = Paint.Style.FILL
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }
    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 10f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val size = Math.min(w, h) * 0.8f
        val cx = w/2f
        val cy = h/2f + size*0.1f

        val headRect = RectF(cx - size*0.45f, cy - size*0.35f, cx + size*0.45f, cy + size*0.25f)
        val path = Path()
        path.moveTo(headRect.left, headRect.top + size*0.15f)
        path.quadTo(cx, headRect.top - size*0.2f, headRect.right, headRect.top + size*0.2f)
        path.lineTo(headRect.right, headRect.centerY() + size*0.05f)
        path.quadTo(cx + size*0.3f, headRect.centerY() + size*0.15f, cx + size*0.15f, headRect.centerY() + size*0.18f)
        path.lineTo(cx - size*0.25f, headRect.centerY() + size*0.2f)
        path.quadTo(headRect.left - size*0.1f, headRect.centerY() - size*0.1f, headRect.left, headRect.top + size*0.15f)
        path.close()
        canvas.drawPath(path, paint)
        canvas.drawPath(path, stroke)

        canvas.drawCircle(cx + size*0.15f, headRect.top + size*0.1f, size*0.025f, eyePaint)

        val teeth = Paint(eyePaint).apply { color = Color.WHITE }
        val toothY = headRect.centerY() + size*0.14f
        for (i in 0..6) {
            val tx = cx - size*0.25f + i * size*0.08f
            val tooth = Path()
            tooth.moveTo(tx, toothY)
            tooth.lineTo(tx + size*0.03f, toothY + size*0.07f)
            tooth.lineTo(tx + size*0.06f, toothY)
            tooth.close()
            canvas.drawPath(tooth, teeth)
            canvas.drawPath(tooth, stroke)
        }

        val mouth = Path()
        if (state == State.ANGRY) {
            mouth.moveTo(cx - size*0.32f, headRect.centerY() + size*0.12f)
            mouth.lineTo(cx - size*0.1f, headRect.centerY() + size*0.24f)
            mouth.lineTo(cx + size*0.22f, headRect.centerY() + size*0.14f)
        } else {
            mouth.moveTo(cx - size*0.3f, headRect.centerY() + size*0.18f)
            mouth.quadTo(cx, headRect.centerY() + size*0.28f, cx + size*0.25f, headRect.centerY() + size*0.16f)
        }
        canvas.drawPath(mouth, mouthPaint)
    }
}