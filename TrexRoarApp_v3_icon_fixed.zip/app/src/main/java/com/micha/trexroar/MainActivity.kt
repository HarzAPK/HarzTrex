package com.micha.trexroar

import android.media.*
import android.os.*
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.micha.trexroar.databinding.ActivityMainBinding
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var binding: ActivityMainBinding
    private var tts: TextToSpeech? = null
    private var soundPool: SoundPool? = null
    private var soundId: Int = 0
    private var audioManager: AudioManager? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        tts = TextToSpeech(this, this)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder().setMaxStreams(1).setAudioAttributes(attrs).build()
        soundId = soundPool!!.load(this, R.raw.dino_roar, 1)

        binding.root.setOnClickListener { startSequence() }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        soundPool?.release()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.GERMANY
            tts?.setPitch(0.95f)
            tts?.setSpeechRate(0.98f)
        }
    }

    private fun startSequence() {
        binding.hint.visibility = View.GONE
        with(binding.trexView) {
            visibility = View.VISIBLE
            state = TrexView.State.ANGRY
            alpha = 0f
            scaleX = 0.7f
            scaleY = 0.7f
            animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(350).setInterpolator(AccelerateDecelerateInterpolator())
                .withEndAction { roarThenGreet() }.start()
        }
    }

    private fun flashScreen(durationMs: Long = 400) {
        val v = binding.flashOverlay
        v.visibility = View.VISIBLE
        v.alpha = 0f
        v.animate().alpha(0.9f).setDuration(60).withEndAction {
            v.animate().alpha(0f).setDuration(durationMs).withEndAction {
                v.visibility = View.GONE
            }.start()
        }.start()
    }

    private fun vibratePattern() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val effect = VibrationEffect.createWaveform(longArrayOf(0,150,50,150,50,120), intArrayOf(255,180,255,180,200,160), -1)
            vibrator?.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(longArrayOf(0,150,50,150,50,120), -1)
        }
    }

    private fun roarThenGreet() {
        // Flash + Vibrate + Roar sound
        flashScreen()
        vibratePattern()
        soundPool?.setOnLoadCompleteListener { _, _, _ ->
            playRoarThenSpeak()
        }
        if (soundId != 0) {
            playRoarThenSpeak()
        }
    }

    private fun playRoarThenSpeak() {
        val streamId = soundPool?.play(soundId, 1f, 1f, 1, 0, 1f)
        // Switch to grin shortly after start
        binding.trexView.postDelayed({
            binding.trexView.state = TrexView.State.GRIN
        }, 400)

        // After sound finishes (~1.6s), speak time
        binding.trexView.postDelayed({
            sayTime()
        }, 1700)
    }

    private fun sayTime() {
        val time = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        } else {
            java.text.SimpleDateFormat("HH:mm", Locale.GERMANY).format(java.util.Date())
        }
        val speech = "Moin, es ist $time Uhr."
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tts?.speak(speech, TextToSpeech.QUEUE_FLUSH, null, "greet")
        } else {
            @Suppress("DEPRECATION")
            tts?.speak(speech, TextToSpeech.QUEUE_FLUSH, null)
        }
    }
}