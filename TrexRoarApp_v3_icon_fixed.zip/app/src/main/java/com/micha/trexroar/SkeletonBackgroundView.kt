package com.micha.trexroar

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class SkeletonBackgroundView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E8E2D0")
        style = Paint.Style.STROKE
        strokeWidth = 12f
    }
    private val faint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1AFFFFFF")
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        val path = Path()
        path.moveTo(w*0.1f, h*0.7f)
        path.quadTo(w*0.35f, h*0.4f, w*0.6f, h*0.55f)
        path.quadTo(w*0.75f, h*0.6f, w*0.9f, h*0.5f)
        val p2 = Path(Path.FillType.EVEN_ODD)
        p2.addPath(path)
        val bg = Paint(faint)
        canvas.drawPath(p2, bg)

        for (i in 0..10) {
            val x = w*0.12f + i * (w*0.07f)
            val y = h*0.68f - i*(h*0.02f)
            canvas.drawCircle(x, y, 10f, bone)
        }
        for (i in 0..6) {
            val x = w*0.25f + i * (w*0.05f)
            val y = h*0.62f - i*(h*0.015f)
            val rib = RectF(x-40f, y-20f, x+40f, y+20f)
            canvas.drawArc(rib, 200f, 140f, false, bone)
        }
        val skull = RectF(w*0.62f, h*0.42f, w*0.85f, h*0.58f)
        canvas.drawOval(skull, bone)
        val jaw = Path()
        jaw.moveTo(w*0.62f, h*0.55f)
        jaw.quadTo(w*0.7f, h*0.62f, w*0.82f, h*0.56f)
        canvas.drawPath(jaw, bone)
        for (i in 0..8) {
            val tx = w*0.1f + i*(w*0.06f)
            val ty = h*0.7f + i*(h*0.02f)
            canvas.drawCircle(tx, ty, 6f, bone)
        }
    }
}